from game_data import data
from art import vs
import random

Alist = random.choice(data)
Blist = random.choice(data)
    
aname = Alist["name"]
bname = Blist["name"]

afc = Alist["follower_count"]
bfc = Blist["follower_count"]

adescr = Alist["description"]
bdescr = Blist["description"]

acountry = Alist["country"]
bcountry = Blist["country"]

def igdata(list):
  listname = list["name"]
  listdescr = list["description"]
  listcountry = list["country"]
  return f"{listname}, a {listdescr}, from {listcountry}."

print(f"Compare A: {igdata(Alist)}.")
print(vs)
print(f"Against B: {igdata(Blist)}.")

count = 0

loop = True

while loop == True:
  fc = input("Who has more followers? Type 'A' or 'B': ").lower()

  if (afc > bfc and fc == "a") or (bfc > afc and fc == "b"):
    Alist = Blist
    Blist = random.choice(data)
    count += 1
    print (f"You're right! Current score: {count}")
    print(f"Compare A: {igdata(Alist)}.")
    print(vs)
    print(f"Against B: {igdata(Blist)}.")
  else:
    loop = False
    print("\nSorry, that is not correct.")
    print(f"Final score: {count}")


